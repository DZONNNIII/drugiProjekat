package projekat1;

public interface MatricaSume {
    double sumaElemenata();
}
